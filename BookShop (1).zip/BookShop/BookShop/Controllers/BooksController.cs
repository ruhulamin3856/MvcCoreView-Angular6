﻿
using BookShop.Data;
using BookShop.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BookShop.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookContext _context;

        public BooksController(BookContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var books = _context.Books.ToList();

            var model = new BookListViewModel()
            {
                Books = books
            };

            return new JsonResult(model);
        }



        [HttpGet]
        public IActionResult Get(int? Id)
        {
            var _book = _context.Books.FirstOrDefault(b => b.BookId == Id);

            var model = new BookViewModel()
            {
                Book = _book
            };

            return new JsonResult(model);
        }

        [HttpPost]
        public IActionResult Update(Book book)
        {
            var _book = _context.Books.FirstOrDefault(b => b.BookId == book.BookId);
            _book.Title = book.Title;
            _book.Author = book.Author;
            _book.IsAvailable = book.IsAvailable;
            _context.SaveChanges();

            var model = new BookViewModel()
            {
                Book = _book
            };

            return new JsonResult(model);
        }

        public IActionResult Delete(int? Id)
        {
            var _book = _context.Books.FirstOrDefault(b => b.BookId == Id);
            _context.Books.Remove(_book);
            _context.SaveChanges();

            var model = new BookListViewModel()
            {
                Books = _context.Books.ToList()
            };

            return new JsonResult(model);
        }

    }
}