/* Register the `studentList` component on the `studentList` module, */
angular.
    module('studentList').
    component('studentList', {
    templateUrl: 'app/templates/student-list.html',
        controller: ['$http', function StudentListController($http) {
            var self = this;
            self.orderProp = 'age';

            //$scope.ConfirmDelete = function (student) {
            //    var delConfirm = confirm("Are you sure to delete "
            //        + student + "?");
            //    if (delConfirm)
            //        return true;
            //    else
            //        return false;                
            //};

            $http.get('/Student/Index').then(function (response) {
                self.students = response.data;                
            });
        }]
  });
