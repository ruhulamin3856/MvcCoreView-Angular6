﻿'use strict';

// Define the `phoneDetail` module
angular.module('studentEdit', [
    'ngRoute'
]);