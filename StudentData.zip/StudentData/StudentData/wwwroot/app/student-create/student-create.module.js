﻿'use strict';

// Define the `phoneDetail` module
angular.module('studentCreate', [
    'ngRoute'
]);