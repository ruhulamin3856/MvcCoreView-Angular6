﻿'use strict';

// Register `studentDetail` component, along with its associated controller and template
angular.
    module('studentDetail').
    component('studentDetail', {
        templateUrl: 'app/templates/student-detail.html',
        controller: ['$http', '$routeParams',
            function StudentDetailController($http, $routeParams) {
                var self = this;

                $http.get('Student/Details/' + $routeParams.studentId).then(function (response) {
                    self.student = response.data;
                });
            }
        ]
    });