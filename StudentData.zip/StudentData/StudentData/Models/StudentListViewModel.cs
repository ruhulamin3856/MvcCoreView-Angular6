﻿using System.Collections.Generic;

namespace StudentData.Models
{
    public class StudentListViewModel
    {
        public List<Student> Students { get; set; }
    }
}