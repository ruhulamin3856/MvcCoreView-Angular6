﻿using StudentManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagment.Services
{
   public interface IStudentService
    {
        Task<List<Student>> List();
        Task<Student> Details(int? Id);
        Task<Student> Create(Student student);
        Task<Student> Edit(Student student);
        Task<List<Student>> Delete(int? Id);
        Task Create(int studentApp);
        Task Creates(object students);
    }
}
