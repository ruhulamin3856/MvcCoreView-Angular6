﻿using StudentManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagment.Services
{
    public class StudentServiceProvider: IStudentService
    {
        private readonly StudentContext _context;

        public StudentServiceProvider(StudentContext context)
        {
            _context = context;
        }

        public StudentServiceProvider()
        {
        }

        public Task<List<Student>> List()
        {
            var students = _context.Students.ToList();
            return Task.FromResult(students);
        }

        public Task<Student> Details(int? Id)
        {
            var student = _context.Students.FirstOrDefault(s => s.Id == Id);
            return Task.FromResult(student);
        }

        public Task<Student> Create(Student student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();
            return Task.FromResult(student);
        }

        public Task<Student> Edit(Student student)
        {
            var stdUpdate = _context.Students.FirstOrDefault
                            (s => s.Id == student.Id);
            //stdUpdate.Name = student.Name;
            //stdUpdate.Class = student.Class;
            //_context.SaveChanges();
            return Task.FromResult(student);
        }

        public Task<List<Student>> Delete(int? Id)
        {
            var student = _context.Students.FirstOrDefault
                          (s => s.Id == Id);
            _context.Students.Remove(student);
            _context.SaveChanges();
            return Task.FromResult(_context.Students.ToList());
        }

        public Task Create(int studentApp)
        {
            throw new NotImplementedException();
        }
        public Task Creates(object students)
        {
            throw new NotImplementedException();
        }
    }
}