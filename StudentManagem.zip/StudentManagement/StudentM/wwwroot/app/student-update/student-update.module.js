﻿//'use strict';

//// Define the `phoneDetail` module
//angular.module('studentUpdate', [
//    //'ngRoute'
//]);