﻿/* Register the `studentList` component on the `studentList` module, */
angular.
    module('studentList').
    component('studentList', {
        templateUrl: 'app/templates/student-list.html',
        controller: ['$http', function StudentListController($http) {
            var self = this;
            self.orderProp = 'age';
            $http.get('/Student/Index').then(function (response) {
                self.students = response.data;
            });
            //self.delete = function (event) { alert($event); event }
        }]
    });
