﻿'use strict';
// Register `studentDetail` component, along with its associated controller and template
angular.
    module('studentDelete').
    component('studentDelete', {
        //templateUrl: 'app/templates/student-Delete.html',
        controller: ['$http', '$routeParams','$location',
            function StudentDetailController($http, $routeParams,$location) {
                var self = this;
                var confirmWin = confirm("Are you sure delete Document ?");
                if (confirmWin) {
                    //var self = this;
                    $http.get('/Student/Delete/' + $routeParams.studentId)
                        .then(function (response) {
                            alert('Data delete Sucessfully,' + $routeParams.studentId + 'deleted.');
                            self.students = response.data;
                            $location.path("/");
                        });
                    }               
            }]        
    });