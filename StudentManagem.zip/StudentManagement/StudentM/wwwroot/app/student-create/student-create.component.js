﻿'use strict';
angular.
    module('studentCreate').
    component('studentCreate', {
        templateUrl: 'app/templates/student-create.html',
        controller: ['$scop', '$http', '$loaction',
            function StudentCreateController($scop, $http, $loaction) {
                $scop.Create = function () {
                    $http({
                        method: 'POST',
                        url: '/Student/Create/',
                        data: $.param($scop.student),
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    }).then(function (respons) {
                        alert("New  student," + respons.data.student.name + "create succussfully !");
                        $location.path('/students/' + respons.data.student.id);
                    });
                };
            }
        ]
    });