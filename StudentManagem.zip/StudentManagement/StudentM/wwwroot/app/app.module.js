﻿// Define the `studentApp` module
angular.module('studentApp', [ 
    'studentCreate',
    'studentList',
    'ngRoute',
    'studentDetail',
    'studentDelete'
]);
