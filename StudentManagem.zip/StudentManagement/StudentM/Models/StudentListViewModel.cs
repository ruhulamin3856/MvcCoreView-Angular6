﻿using System;
using System.Collections.Generic;

namespace StudentManagment.Models
{
    public class StudentListViewModel
    {
        public List<Student> Students { get; set; }     
    }
}
