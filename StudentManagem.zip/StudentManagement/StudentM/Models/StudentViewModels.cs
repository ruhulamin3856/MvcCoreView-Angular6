﻿using System;

namespace StudentManagment.Models
{
    public class StudentViewModels
    {
        public Student Student { get; set; }
    }
}
