﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentManagment.Services;
using StudentManagment.Models;

namespace StudentManagment.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentService _service;

        public StudentController(IStudentService service)
        {
            _service = service;
        }


        public async Task<IActionResult> Index()
        {
            var students = await _service.List();

            var model = new StudentListViewModel()
            {
                Students = students
            };

            return new JsonResult(model);
        }      
        public async Task<IActionResult> Details(int Id)
        {
            var student = await _service.Details(Id);

            var model = new StudentViewModels()
            {
                Student = student
            };

            return new JsonResult(model);
        }

        public async Task<IActionResult> Delete(int Id)
        {
            var students = await _service.Delete(Id);

            var model = new StudentListViewModel()
            {
                Students = students
            };

            return new JsonResult(model);
        }

        public async Task<IActionResult> Create(Student student)
        {
            var studentInsert = await _service.Create(student);
            var model = new StudentViewModels()
            {
                Student = studentInsert
            };
            return new JsonResult(model);

        }
    }
}